package atv1;

import java.util.Scanner;

public class exer1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num1,num2,num3,med;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Informe a primeira nota");
		num1 = entrada.nextInt();
		System.out.println("Informe a segunda nota");
		num2 = entrada.nextInt();
		System.out.println("Informe a terceira nota");
		num3 = entrada.nextInt();
		
		
		med = (num1+num2+num3)/3;
		
		if(med >= 7) {
			System.out.println("Aprovado");
		}
		else {
			System.out.println("Reprovado");
		}
		entrada.close();

	}

}
