package atv10;

import java.util.Scanner;

public class atv10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner entrada = new Scanner(System.in);
		
		String carro;
		int gs, li;
		
		
		
		System.out.println("Informe o modelo do carro");
	      carro = entrada.nextLine();
	      
	      System.out.println("Informe a capacidade do tanque");
	      li = entrada.nextInt();

	      System.out.println("Movido a gasolina(1) ou álcool(2)?");
	      gs = entrada.nextInt();

	     
	      
	      
	      switch(gs){
	      
	      
	      case 1:
        	  System.out.println("Para encher o tanque de seu " +carro+ " será necessário"+ (li*1.8) +"R$" );
              break;
	      case 2:
        	  System.out.println("Para encher o tanque de seu " +carro+ " será necessário"+ (li*1) +"R$" );
        	  break;

	      }
		
		entrada.close();
	}

}
