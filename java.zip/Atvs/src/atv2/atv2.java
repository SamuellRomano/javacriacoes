package atv2;

import java.util.Scanner;

public class atv2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int ida;	
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Informe sua idade");
		ida = entrada.nextInt();
		
		if(ida >= 18) {
			System.out.println("Maior de idade");
		}
		else {
			System.out.println("Menor de idade");
		}
		entrada.close();
	}

}
