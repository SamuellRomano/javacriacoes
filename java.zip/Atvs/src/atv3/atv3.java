package atv3;

import java.util.Scanner;

public class atv3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num1,num2,num3;
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Informe um número");
		num1 = entrada.nextInt();
		System.out.println("Informe outro número");
		num2 = entrada.nextInt();
		System.out.println("Informe o ultimo número");
		num3 = entrada.nextInt();
		
		if(num1 > num2){
			if(num1 > num3){
			System.out.println(num1+" é o maior número");	
			}
			else{
				System.out.println(num3+" é o maior núemro");
			}
		}
		else {
			if(num2 > num3) {
				System.out.println(num2+" é o maior número");
			}
			else {
				System.out.println(num3+" é o maior número");
			}
		}
	entrada.close();
	}
	

}
