package atv4;

import java.util.Scanner;

public class atv4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sal,ano;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Informe seu salário");
		
		sal = entrada.nextInt();
		
		System.out.println("Informe os anos de empresa");
		
		ano = entrada.nextInt();
		
		if(ano >= 5) {
			sal = sal+((sal/100)*20);
		}
		else {
			sal = sal+((sal/100)*10);
		}
		System.out.println("Seu salário é "+sal+"R$");
	entrada.close();
	
	}
	

}
