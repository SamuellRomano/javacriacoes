package atv5;

import java.util.Scanner;

public class atv5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
			int sal,par,val;
			Scanner entrada = new Scanner(System.in);
	
			System.out.println("Informe seu salário");
			sal = entrada.nextInt();
			System.out.println("Informe a quantia do emprestimo");
			val = entrada.nextInt();
			System.out.println("Em quantas vezes");
			par = entrada.nextInt();
			
			sal = (sal/100)*30;
			val = val/par;
			
			if(val <= sal) {
				System.out.println("Empréstimo aprovado");
			}
			else {
				System.out.println("Empréstimo negado");
			}
			
	}

}
