package atv6;

import java.util.Scanner;

public class atv6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num1;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Informe um número");
		num1 = entrada.nextInt();
		if(num1 %2 == 0) {
			System.out.println(num1+" é par");
			
		}
		else {
			System.out.println(num1+" é impar");
		}
	entrada.close();
	}
	

}