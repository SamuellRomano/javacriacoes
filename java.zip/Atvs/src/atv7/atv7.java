package atv7;

import java.util.Scanner;

public class atv7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int cum;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Informe o valor total das comissões");
		
		cum = entrada.nextInt();
		
		if(cum >= 2000){
			System.out.println("Seu salário desse mês é de " +(1200+(cum/10)) + "R$" );
		}
			else {
				System.out.println("Seu salário desse mês é de 1200R$");
			}
		
	
		}
		
	}


