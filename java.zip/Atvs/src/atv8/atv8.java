package atv8;

import java.util.Scanner;

public class atv8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 
		Scanner entrada = new Scanner(System.in);

		 char sex;
		 double alt;
		 
	System.out.println("Informe sua altura em metros");
	alt = entrada.nextDouble();
	System.out.println("Informe seu sexo masculino (M) ou feminino (F)");
	sex = entrada.next().charAt(0);
	
	switch(sex) {
	
	case 'M':
		System.out.println("Seu peso ideal é "+ ((alt*72.7)-58));
		
		break;
		
	case 'F':
		System.out.println("Seu peso ideal é"+ ((alt*62.1)-44.7));
		break;
		

	
	}
	
	entrada.close();
	}

}
