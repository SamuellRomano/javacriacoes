package atv9;

import java.util.Scanner;

public class atv9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner entrada = new Scanner(System.in);
		
		int n1,n2,min1,min2,hor = 0,dia;
		
		System.out.println("Informe as horas de chegada");
		n1 = entrada.nextInt();
		System.out.println("Informe os minutos de chegada");
		min1 = entrada.nextInt();
		
		System.out.println("Informe as horas de saida");
		n2 = entrada.nextInt();
		System.out.println("Informe os minutos de saida");
		min2 = entrada.nextInt();
		
		
		System.out.println("Entrada e saida no mesmo dia?");
		System.out.println("Sim(1)");
		System.out.println("Não(2)");
		dia = entrada.nextInt();
		
		switch(dia) {
		
		case 2:
			System.out.println(hor=((24-n1) +n2));
			break;
				
		case 1:
			System.out.println(hor = (n2-n1));
			
			break;
			}
					
					if(min2-min1 > 0){
						hor = (hor + 1);
						
						
					}
					else {
						
					
					 if (hor > 1){
						 System.out.println("Vai custar " + ((( hor-2 )* 1) + 6) +"R$");
					 }

					 else{
						 System.out.println("Vai custar 4R$");
					 	}
		
		}
		
					entrada.close();

		
		
		
		
	}

}
