package atv1;

import java.util.Scanner;

public class atv1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num,soma;
		char escolha;
		escolha = 'S';
		soma = 0;
		Scanner entrada = new Scanner(System.in);
		
		while(escolha == 'S'){
		
		System.out.println("fale um número");
		num = entrada.nextInt();
		
		soma = soma + num;
		
		System.out.println("A soma é " + soma);
		
		
		System.out.println("Deseja continuar? (S) (N)");
		escolha = entrada.next().charAt(0);
		
		}
		
				
		
		
		
		
		entrada.close();
	}

}
