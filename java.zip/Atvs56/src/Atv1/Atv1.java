package Atv1;

import java.util.Scanner;

public class Atv1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner leitura = new Scanner(System.in);
		byte opcao = 1;
		int num1,num2;
		
		
		System.out.println("Bem vindo a calculadora!");
		System.out.println("Informe o primeiro número");
		num1 = leitura.nextInt();
		


		
		while ((opcao != 0) && (opcao <=4)) {
			System.out.println("****************");
			System.out.println("(0) Sair");
			System.out.println("(1) Somar");
			System.out.println("(2) Subtrair");
			System.out.println("(3) Multiplicar");
			System.out.println("(4) Dividir");
			System.out.println("(?) Opção:");
			opcao = leitura.nextByte();
			System.out.println("****************");
			

			
			switch(opcao) {
			
			case 1 :
				System.out.println("Informe outro número");
				num2 = leitura.nextInt();
				num1 = num1 + num2 ;
				

				
				break;
				
			case 2 :
				System.out.println("Informe outro número");
				num2 = leitura.nextInt();
				num1 = num1 - num2 ;
				


				
				break;
			
			case 3 :
				System.out.println("Informe outro número");
				num2 = leitura.nextInt();
				num1 = num1 * num2 ;
				


				
				break;
				
			case 4 :
				System.out.println("Informe outro número");
				num2 = leitura.nextInt();
				num1 = num1 / num2 ;
				
	

				
				break;			

			}
			
			System.out.println("O resultado é");
			System.out.println(num1);

			
		}
		
		
		leitura.close();
		
		
		
		
		
	}
	

}
