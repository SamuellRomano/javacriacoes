package Atv2;

import java.util.Scanner;

public class atv2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int ini,fim,num;
	
	Scanner entrada = new Scanner(System.in);
	
	
	System.out.println("Informe o número para ver sua tabuada");
	num = entrada.nextInt();
	
	System.out.println("A tabuada deve começar em "+num+" X quanto?");
	ini = entrada.nextInt();
	
	System.out.println("E deve terminar em "+num+" X quanto?");
	fim = entrada.nextInt();
	
	if(ini>fim){
		System.out.println("Por favor informe o inicio e fim na ordem correta, a tabuada não pode começar em um número maior e ir diminuindo");
	
		
		
	}
	else {
		
		while(ini <= fim){
			
			System.out.println(num +"*"+ ini + " = " + (num*ini));
			ini++;		
		
	
	}

}
	entrada.close();
	}
}
