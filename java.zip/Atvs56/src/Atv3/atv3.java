package Atv3;

import java.util.Scanner;

public class atv3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner entrada = new Scanner(System.in);
		
		double valor;
		int cod;
		char opcao;
		valor = 0;
		
		System.out.println("Bem vindo a lanchonte Espanta Cachorro, aqui está nosso cardápio:");
		System.out.println("Especificação    Código   Preço");
		System.out.println("Cachorro Quente   100    R$ 1,20");
		System.out.println("Bauru Simples     101    R$ 1,30");
		System.out.println("Bauru com ovo     102    R$ 1,50");
		System.out.println("Hambúrguer        103    R$ 1,20");
		System.out.println("Cheeseburguer     104    R$ 1,30");
		System.out.println("Refrigerante      105    R$ 1,00");
		
		do {
			System.out.println("Oque deseja? (Informe o código) ");
			cod = entrada.nextInt();
			
			switch(cod) {
			
			case 100:
				 valor = valor + 1.20;
				 
				break;
			
			case 101:
				 valor = valor + 1.30;
				 
				break;
				
			case 102:
				 valor = valor + 1.50;
				 
				break;
				
			case 103:
				 valor = valor + 1.20;
				 
				break;
				
			case 104:
				 valor = valor + 1.30;
				 
				break;
			
			case 105:
				 valor = valor + 1.00;
				 
				break;
			
				
			
			}
			
			System.out.println("Exelente escolha!");
			System.out.println("Gostaria de mais alguma coisa? (S) (N)");
			opcao = entrada.next().charAt(0);
			
	
		} while (opcao != 'n' && opcao != 'N');

		System.out.println("Isso tudo vai sair por apenas "+ valor+ "R$ senhor(a), obrigado e volte sempre");
		
		
		
		entrada.close();
	}

}
