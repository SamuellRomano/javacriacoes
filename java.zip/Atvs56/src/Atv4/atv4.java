package Atv4;

import java.util.Random;
import java.util.Scanner;

public class atv4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rnd = new Random(); //Inicia Aleatório
		int x = rnd.nextInt(15); //Gera um número aleatório (0 – 15)
		
		int vi,chut,chan;
		vi = 1;
		chan = 0;
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Tente adivinhar o número que eu estou pensando, dica: ele é de 0 a 15, você tem 5 chances");
		
		while (vi == 1) {
			System.out.println("Faça seu chute");
			chut = entrada.nextInt();
			chan++;

			if (chut == x) {
				vi = 0;
				System.out.println("Você ganhou!");
			chan = 0;
			}
			if (chan == 5) {
				vi = 0;
				System.out.println("Você perdeu! era " +x);
			}
			else {			
			
			if (chut > x) {
				System.out.println("É menor");
			}
			
			if (chut < x){
				System.out.println("É maior");
			}
			}
			
		
		}
		entrada.close();
	}

}
