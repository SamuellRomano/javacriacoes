package Atv5;

import java.util.Scanner;

public class atv5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	    
		Scanner entrada = new Scanner(System.in);
		
		
	
		
	}
}
