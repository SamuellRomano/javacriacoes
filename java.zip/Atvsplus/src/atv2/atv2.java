package atv2;

import java.util.Scanner;

public class atv2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int km,kmx;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Qual a velocidade máxima da avenida? (Em km/h)");
		kmx = entrada.nextInt();
		
		System.out.println("Qual era a velocidade do veículo? (Em km/h");
		km = entrada.nextInt();
		
		if( km > kmx) {
			System.out.println("A multa será de "+ (5*(km - kmx))  + "R$");
			
			
		}
		else {
			System.out.println("A velocidade está dentro do limite");
		}
		entrada.close();
	}

}
