package atv3;

import java.util.Scanner;

public class atv3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double hor;
		int horm;
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Quanto você recebe por hora?");
		hor = entrada.nextDouble();
		
		System.out.println("Quantas horas você trabalha por mês");
		horm = entrada.nextInt();
		
		System.out.println("Seu salário vai ser de "+ (hor*horm)+ "R$");
	
		entrada.close();
	}

}
