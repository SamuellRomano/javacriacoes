package exemplopara;

public class exemplofor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Estrutura Controlada numéricamente

	       int i;//inteiro que controla a estrutura

	       

	       //para (i=0;i<=10;i++){

	       

	       for(i=1;i<=5;i++) {

	           System.out.println("volta numero " +i);

	           

	       }
	}
;
}
