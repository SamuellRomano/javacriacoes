package exemplowhile;

import java.util.Scanner;

public class enquanto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		   int num;

	       char opcao;

	       opcao = 'S';

	       Scanner entrada = new Scanner(System.in);

	       

	       while(opcao =='S'){

	           System.out.println("Digite um numero");

	           num = entrada.nextInt();

	           if(num%2==0)

	               System.out.println("numero par");

	           else

	               System.out.println("numero impar");

	           System.out.println("Deseja continuar 'S'- Sim / 'N' - Não);");

	           opcao= entrada.next().charAt(0);

	      
	       }
	       entrada.close();
	}

}
