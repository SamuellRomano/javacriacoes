package matrizes2;

public class matrizes2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[][] clientes = new String[3][2];
		long[][] clientesint = new long[3][2];
		
		clientes[0][0] = "João";
		clientes[0][1] = "Rua das Flores, 123";
		clientes[1][0] = "Maria";
		clientes[1][1] = "Avenida dos Anjos, 456";
		clientes[2][0] = "Pedro";
		clientes[2][1] = "Praça da Liberdade, 789";
		
		clientesint[0][0] = 27685710024L;	
		clientesint[1][0] = 94212224070L;		
		clientesint[2][0] = 79968748080L;		
		
		clientesint[0][1] = 11601287346L;		
		clientesint[1][1] = 11431478119L;		
		clientesint[2][1] = 11461413467L;	


		for(int i = 0; i < 3 ;i++) {
			System.out.println("Nome: " + clientes[i][0]);
			System.out.println("Endereço: " + clientes [i][1]);
			System.out.println("CPF: " + clientesint[i][0]);
			System.out.println("Telefone: " + clientesint [i][1]);
			System.out.println();
		}
}
}