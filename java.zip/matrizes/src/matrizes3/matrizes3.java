package matrizes3;

public class matrizes3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char [] [] matriz1 = new char [4] [5];

		int [] [] matriz2 = new int [3] [4];

		double [] [] matriz3 = new double [3] [3];
		
		matriz1 [0][0] = 'a';
		matriz1 [1][0] = 'f';
		matriz1 [2][0] = 'l';
		matriz1 [3][0] = 'q';
		matriz1 [0][1] = 'b';
		matriz1 [1][1] = 'g';
		matriz1 [2][1] = 'm';
		matriz1 [3][1] = 'r';
		matriz1 [0][2] = 'c';
		matriz1 [1][2] = 'h';
		matriz1 [2][2] = 'n';
		matriz1 [3][2] = 's';
		matriz1 [0][3] = 'd';
		matriz1 [1][3] = 'i';
		matriz1 [2][3] = 'o';
		matriz1 [3][3] = 't';
		matriz1 [0][4] = 'e';
		matriz1 [1][4] = 'j';
		matriz1 [2][4] = 'p';
		matriz1 [3][4] = 'u';
		
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 5; j++) {
				System.out.print("| " + matriz1[i][j] + " ");
			}
				System.out.print("|");
				System.out.println();
			}

		matriz2 [0][0] = 19;
		matriz2 [0][1] = 25;
		matriz2 [0][2] = 100;
		matriz2 [0][3] = 99;
		matriz2 [1][0] = 10;
		matriz2 [1][1] = 7;
		matriz2 [1][2] = 25;
		matriz2 [1][3] = 14;
		matriz2 [2][0] = 35;
		matriz2 [2][1] = 2;
		matriz2 [2][2] = 47;
		matriz2 [2][3] = 74;

		System.out.println("\n\n\n\n");
		
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 4; j++) {
				System.out.print("| " + matriz2[i][j] + " ");
			}
				System.out.print("|");
				System.out.println();
			}

		matriz3 [0][0] = 1.9;
		matriz3 [0][1] = 2.5;
		matriz3 [0][2] = 10;
		matriz3 [1][0] = 1;
		matriz3 [1][1] = 7.8;
		matriz3 [1][2] = 2.5;
		matriz3 [2][0] = 3.5;
		matriz3 [2][1] = 2.2;
		matriz3 [2][2] = 4.7;
		
		System.out.println("\n\n\n\n");


		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				System.out.print("| " + matriz3[i][j] + " ");
			}
				System.out.print("|");
				System.out.println();
		}
		
	
	}

}
