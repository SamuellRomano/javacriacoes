package matrizes4;

import java.util.Scanner;

public class matrizes4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[][] tabela = new int[5][5];
		
		int[] linhasoma = new int [5];
		
		int[] columsoma = new int [5];

		
		int somimp = 0;
		
		Scanner entrada = new Scanner(System.in);
		
		for(int i = 0; i <=4;i++) {
			for(int j = 0; j<=4;j++) {
				System.out.println("Digite um número");
				tabela[i][j] = entrada.nextInt();
			}
		}
		
		
		System.out.println("\n\n\n\n\n\n\n\n\n\n");
		System.out.println("Sua tabela:");
		
		for(int i = 0; i <= 4; i++) {
			for(int j = 0; j <= 4; j++) {
				System.out.print("| " + tabela[i][j] + " ");
			}
				System.out.print("|");
				System.out.println();
		}
		
		
		System.out.println("\n\n");
		
		
		for(int i = 0; i <=4;i++) {
			for(int j = 0; j<=4;j++) {
				if(tabela[i][j]%2!=0 ) {
					
					somimp += tabela[i][j]; 
					
				}
				 
			}
		}
		
		
		for(int i = 0; i <=4;i++) {
			for(int j = 0; j<=4;j++) {
				linhasoma[i] += tabela[i][j];
				
			}
		}
		
		for(int j = 0; j <=4;j++) {
			for(int i = 0; i<=4;i++) {
				columsoma[j] += tabela[i][j];
				
			}
		}
		
		for(int i = 0; i <=4;i++) {

			System.out.println("Soma da "+(i+1)+"º linha :");
			System.out.println(linhasoma[i]);
		}
		
		System.out.println("\n\n");
		
		for(int i = 0; i <=4;i++) {

			System.out.println("Soma da "+(i+1)+"º coluna :");
			System.out.println(columsoma[i]);
		}
		
		System.out.println("\n\n");
		
		System.out.println("Soma dos números impares: " + somimp);
		
		entrada.close();
	}

}
