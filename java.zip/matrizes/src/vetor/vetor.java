package vetor;

import java.util.Scanner;

public class vetor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] valores = new int[10];
		int soma = 0;
		
		
		
		Scanner entrada = new Scanner(System.in);
		
		for(int i = 0;i <5; i++) {
			System.out.println("Digite um número");
			valores[i] = entrada.nextInt();
			
		soma += valores[i];
			
			
		}
		
		System.out.println("A soma desses números é de " + soma);
		
		
		entrada.close();
		
		
	}
	

}
