package vetor2;

import java.util.Scanner;

public class vetor2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] valores = new int[10];

		Scanner entrada = new Scanner(System.in);
		
		
		for (int i = 0; i < 10; i++) {
			
			System.out.println("Digite um número");
			valores[i] = entrada.nextInt();
			
		}
		
		System.out.println("A ordem inversa desses números é:");

		for (int i = 9; i > -1; i--) {
			
			System.out.println(valores[i]);
			
		}

	}

}
