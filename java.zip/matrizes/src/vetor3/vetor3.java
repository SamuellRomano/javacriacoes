package vetor3;
import java.util.Scanner;
public class vetor3 {
	public static void main(String[] args) {

		int[] numbers = new int[5];
		int soma = 0, media;
		
		Scanner entrada = new Scanner(System.in);
		
		for(int i = 0; i <=4; i++) {
			System.out.println("Digite a "+(i+1)+"º nota");
			numbers[i] = entrada.nextInt();
			
			soma += numbers[i];
			
		}
		
		media = soma/5;
		
		for(int i = 0;i <= 4;i++) {
			if (numbers[i] > media) {
				System.out.println(numbers[i] + " é maior que a média");
				
			}
			if (numbers[i] < media) {
				System.out.println(numbers[i] + " é menor que a média");
				
			}
			if (numbers[i] == media) {
				System.out.println(numbers[i] + " é igual que a média");

			}
		}	
		entrada.close();
	}

}
