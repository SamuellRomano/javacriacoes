package paranojento3;

import java.util.Scanner;

public class para3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int soma = 0, par = 0, nu;
		
		Scanner entrada = new Scanner(System.in);
		
		for(int i = 1; i<=10 ; i++) {
			System.out.println("Digite um número positivo");
			nu = entrada.nextInt();
			
			soma += nu;
			
			if(nu%2==0) {
				par += nu;
			}
			
			
		}
		
		
		System.out.println("A soma dos números é " + soma);
		System.out.println("A mêdia dos números é " + (soma/10));
		System.out.println("A mêdia dos números pares é" + (par/10));
		
		
		entrada.close()
		
	}

}
