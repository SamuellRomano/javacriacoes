package paranojento4;

import java.util.Scanner;

public class para4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner entrada = new Scanner(System.in);
		
		int nu, maior = 0, menor = 0;
		
		for(int i = 1; i <=15; i++) {
			System.out.println("Digite um número ");
			nu = entrada.nextInt();
			
			if(i == 1) {
				maior = nu;
				menor = nu;
			}
			
			
			if(nu > maior) {
				maior = nu;
			}
			
			if(nu < menor) {
				menor = nu;
			}
			
		}
		
		System.out.println("O maior número é " + maior);
		System.out.println("O menor número é " + menor);
		
		
		
		entrada.close();
		
	}
	

}
