package prjExemplo1;

import java.util.Scanner;

public class Exemplo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		
		//para armazenar inteiros
		int num1,qtd;
		
		//para armazenar real
		double num2;	
		
		//para armazenar caracteres
		char caracter1,opcao;
		
		//para armazenar palavras
		String palavra1;
		
		//para atribuir valor a uma variável
		num1 = 10;
		
		palavra1 = "programar pode ser difícil se você não não";
		
		num2 = 17.50;
		
		//para exibir algo
		System.out.println(num1);
		System.out.println((num1+num2));
		System.out.println((num1-num2));
		System.out.println((num1/num2));
		System.out.println((num1*num2));
		System.out.println(num2);
		System.out.println(palavra1);
		
		System.out.println(num1+" e "+num2);
		
		//a série de tv iconica "chaves" não foi utilizada aqui
		if(num1 %2 ==0)
				System.out.println("O número é par papai");
		else
				System.out.println("O número ser impar sem chorar");
		
		//a série de tv iconica "chaves" foi utilizada aqui
				if(num1 %2 ==0) {
						System.out.println("O número é par papai");
				}
						else {
						System.out.println("Se vc encara um pincher ele encara de volta");
						}
						
				//Scanner = classe para receber valores digitados
				//entrada = variavel que vai capturar a entrada
				Scanner entrada = new Scanner(System.in);		
				System.out.println("Menu Ticaracatica Lanches");
				System.out.println("Escolha seu lanche");
				System.out.println("A - Misto Quente = 10,00");
				System.out.println("B - X-Salada = 12,00");
				System.out.println("C - X-Bacon = 15,00");
				System.out.println("D - Frangão = 20,00");
				System.out.println("E - Tudão = 25,00");
				//opcao vai receber A B C D ou E
				opcao = entrada.nextLine().charAt (0);
			    System.out.println("Digite a quantidade de Lanches");

			       qtd = entrada.nextInt();
			       switch(opcao)

			       {

			           case 'A':

			               System.out.println("Total a Pagar = "+ qtd * 10);

			               break;

			           case 'B':

			               System.out.println("Total a Pagar = "+ qtd * 12);

			               break;

			           case 'C':

			               System.out.println("Total a Pagar = "+ qtd * 15);

			               break;

			           case 'D':

			               System.out.println("Total a Pagar = "+ qtd * 20);

			               break;

			           case 'E':

			               System.out.println("Total a Pagar = "+ qtd * 25);

			               break;


default: System.out.println("Opção errada burrão");
				}
		
		

	}

}
