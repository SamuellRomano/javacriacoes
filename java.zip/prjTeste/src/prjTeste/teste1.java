package prjTeste;

public class teste1 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Cachorros
		int a=1,b=2,c=3;
		
		System.out.println("a soma dos valores é "+ (a+b+c));
	}
	

}
