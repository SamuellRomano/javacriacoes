package matrizes;

public class matrizes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int [] [] matriz = new int [3] [3];
		
		
		matriz [0] [0] = 1;
		matriz [0] [1] = 2;
		matriz [0] [2] = 3;
		matriz [1] [0] = 4;
		matriz [1] [1] = 5;
		matriz [1] [2] = 6;
		matriz [2] [0] = 7;
		matriz [2] [1] = 8;
		matriz [2] [2] = 9;
		
		
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				System.out.print("| " + matriz[i][j] + " ");
			}
				System.out.print("|");
				System.out.println();
			}
		
		
		String[][] clientes = new String[3][2];
		
		clientes[0][0] = "João";
		clientes[0][1] = "Rua das Flores, 123";
		clientes[1][0] = "Maria";
		clientes[1][1] = "Avenida dos Anjos, 456";
		clientes[2][0] = "Pedro";
		clientes[2][1] = "Praça da Liberdade, 789";
		
		for(int i = 0; i < 3 ;i++) {
			System.out.println("Nome: " + clientes[i][0]);
			System.out.println("Endereço: " + clientes [i][1]);
			System.out.println();
		}

		
		
		}
		
		
		
		
		
	}



