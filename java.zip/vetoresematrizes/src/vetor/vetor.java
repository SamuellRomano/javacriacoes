package vetor;

import java.util.Scanner;

public class vetor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	    int[] vetorInt = new int[10];
	    int notao;
	    notao = 0;

	    Scanner entrada = new Scanner(System.in);


	    for(int i=0;i<=9;i++) {


	    System.out.println("Digite a nota da " + (i+1) + "º prova");

	    vetorInt[i]= entrada.nextInt();    

	    }

	   

	    for(int j = 0;j<=9;j++) {

	         notao = notao + vetorInt[j];     

	    }
	    
	    System.out.println("A média é " + (notao/10));  
	    entrada.close();
	}

}
