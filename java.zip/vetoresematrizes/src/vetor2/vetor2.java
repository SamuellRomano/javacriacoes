package vetor2;

import java.util.Scanner;

public class vetor2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] vetorInt = new int[10], vetorInt2 = new int[10];

	    Scanner entrada = new Scanner(System.in);


	    for(int i=0;i<=9;i++) {


	    System.out.println("Digite o " + (i+1) + "º número");

	    vetorInt[i]= entrada.nextInt();    
	    vetorInt2[i]= vetorInt[i] * 2;   

	    }

	   

	    for(int j = 0;j<=9;j++) {

	         System.out.println("O dobro de " + vetorInt[j] +" é "+ vetorInt2[j]);   

	    }
	
	entrada.close();
	}
	

}
