package vetor3;

import java.util.Scanner;

public abstract class vetor3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int[] vetorInt = new int[5];
		 int[] vetorInt2 = new int[5];
		 int[] vetorInt3 = new int[5];



		    Scanner entrada = new Scanner(System.in);


		    for(int i=0;i<=4;i++) {


		    System.out.println("Digite o " + (i+1) + "º");

		    vetorInt[i]= entrada.nextInt();    

		    }
		    
		    System.out.println("Agora vamos mais 5");
		    
		    for(int j=0;j<=4;j++) {


		    System.out.println("Digite o " + (j+1) + "º");

		    vetorInt2[j]= entrada.nextInt();    
		    vetorInt3[j]= vetorInt[j] + vetorInt2[j];
		    }
		    
		    System.out.println("A soma dos vetores é de ");
		    for(int l=0;l<=4;l++) {

		    	System.out.println(vetorInt[l] + " + " + vetorInt2[l] +" = "+ vetorInt3[l]);


  

		    }
	
	entrada.close();
	
	}

}
